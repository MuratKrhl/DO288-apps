from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from core.models import BaseModel

class LinkCategory(BaseModel):
    """Link kategorileri"""
    name = models.CharField(max_length=100, verbose_name="Kategori Adı")
    description = models.TextField(blank=True, verbose_name="Açıklama")
    icon = models.CharField(max_length=50, default='ri-folder-line', verbose_name="İkon")
    color = models.CharField(max_length=20, default='primary', verbose_name="Renk",
                           choices=[
                               ('primary', 'Mavi'),
                               ('success', 'Yeşil'),
                               ('warning', 'Sarı'),
                               ('danger', 'Kırmızı'),
                               ('info', 'Açık Mavi'),
                               ('secondary', 'Gri'),
                           ])
    order = models.PositiveIntegerField(default=0, verbose_name="Sıralama")
    
    class Meta:
        verbose_name = "Link Kategorisi"
        verbose_name_plural = "Link Kategorileri"
        ordering = ['order', 'name']
    
    def __str__(self):
        return self.name
    
    def get_active_links(self):
        """Aktif linkleri getir"""
        return self.links.filter(is_active=True).order_by('order', 'title')

class ImportantLink(BaseModel):
    """Önemli linkler"""
    CATEGORY_CHOICES = [
        ('monitoring', 'Monitoring'),
        ('documentation', 'Dokümantasyon'),
        ('tools', 'Araçlar'),
        ('external', 'Harici Sistemler'),
        ('development', 'Geliştirme'),
        ('security', 'Güvenlik'),
        ('database', 'Veritabanı'),
        ('network', 'Ağ'),
    ]
    
    category = models.ForeignKey(LinkCategory, on_delete=models.CASCADE, 
                               related_name='links', verbose_name="Kategori")
    title = models.CharField(max_length=100, verbose_name="Başlık")
    url = models.URLField(verbose_name="URL")
    description = models.TextField(blank=True, verbose_name="Açıklama")
    icon = models.CharField(max_length=50, default='ri-link', verbose_name="İkon")
    order = models.PositiveIntegerField(default=0, verbose_name="Sıralama")
    click_count = models.PositiveIntegerField(default=0, verbose_name="Tıklanma Sayısı")
    last_clicked = models.DateTimeField(null=True, blank=True, verbose_name="Son Tıklanma")
    is_featured = models.BooleanField(default=False, verbose_name="Öne Çıkan")
    
    # Ek özellikler
    requires_vpn = models.BooleanField(default=False, verbose_name="VPN Gerektirir")
    is_internal = models.BooleanField(default=True, verbose_name="İç Sistem")
    tags = models.CharField(max_length=200, blank=True, verbose_name="Etiketler",
                          help_text="Virgülle ayırın")
    
    class Meta:
        verbose_name = "Önemli Link"
        verbose_name_plural = "Önemli Linkler"
        ordering = ['category', 'order', 'title']
    
    def __str__(self):
        return f"{self.category.name} - {self.title}"
    
    def increment_click_count(self):
        """Tıklanma sayısını artır"""
        self.click_count += 1
        self.last_clicked = timezone.now()
        self.save(update_fields=['click_count', 'last_clicked'])
    
    def get_tags_list(self):
        """Etiketleri liste olarak döndür"""
        if self.tags:
            return [tag.strip() for tag in self.tags.split(',')]
        return []

class LinkAccessLog(BaseModel):
    """Link erişim logları"""
    link = models.ForeignKey(ImportantLink, on_delete=models.CASCADE, 
                           related_name='access_logs', verbose_name="Link")
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="Kullanıcı")
    accessed_at = models.DateTimeField(auto_now_add=True, verbose_name="Erişim Zamanı")
    ip_address = models.GenericIPAddressField(null=True, blank=True, verbose_name="IP Adresi")
    user_agent = models.TextField(blank=True, verbose_name="User Agent")
    
    class Meta:
        verbose_name = "Link Erişim Logu"
        verbose_name_plural = "Link Erişim Logları"
        ordering = ['-accessed_at']
    
    def __str__(self):
        return f"{self.user.username} - {self.link.title} - {self.accessed_at}"
