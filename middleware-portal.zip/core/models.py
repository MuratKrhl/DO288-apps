from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class BaseModel(models.Model):
    """Temel model - tüm modeller için ortak alanlar"""
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Oluşturulma Tarihi")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Güncellenme Tarihi")
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, 
                                 related_name="%(class)s_created", verbose_name="Oluşturan")
    updated_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True,
                                 related_name="%(class)s_updated", verbose_name="Güncelleyen")
    is_active = models.BooleanField(default=True, verbose_name="Aktif")
    
    class Meta:
        abstract = True

class OnDutySchedule(BaseModel):
    """Nöbetçi programı"""
    date = models.DateField(verbose_name="Tarih", unique=True)
    primary_person = models.CharField(max_length=100, verbose_name="Birincil Nöbetçi")
    secondary_person = models.CharField(max_length=100, blank=True, verbose_name="İkincil Nöbetçi")
    notes = models.TextField(blank=True, verbose_name="Notlar")
    
    class Meta:
        verbose_name = "Nöbetçi Programı"
        verbose_name_plural = "Nöbetçi Programları"
        ordering = ['-date']
    
    def __str__(self):
        return f"{self.date.strftime('%d.%m.%Y')} - {self.primary_person}"

class ImportantLink(BaseModel):
    """Önemli linkler"""
    CATEGORY_CHOICES = [
        ('monitoring', 'Monitoring'),
        ('documentation', 'Dokümantasyon'),
        ('tools', 'Araçlar'),
        ('external', 'Harici Sistemler'),
    ]
    
    title = models.CharField(max_length=100, verbose_name="Başlık")
    url = models.URLField(verbose_name="URL")
    description = models.TextField(blank=True, verbose_name="Açıklama")
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, verbose_name="Kategori")
    icon = models.CharField(max_length=50, default='ri-link', verbose_name="İkon")
    order = models.PositiveIntegerField(default=0, verbose_name="Sıralama")
    
    class Meta:
        verbose_name = "Önemli Link"
        verbose_name_plural = "Önemli Linkler"
        ordering = ['category', 'order', 'title']
    
    def __str__(self):
        return self.title

class MigrationTarget(BaseModel):
    """Migrasyon hedefleri"""
    name = models.CharField(max_length=100, verbose_name="Hedef Adı")
    description = models.TextField(blank=True, verbose_name="Açıklama")
    target_count = models.PositiveIntegerField(verbose_name="Hedef Sayı")
    current_count = models.PositiveIntegerField(default=0, verbose_name="Mevcut Sayı")
    deadline = models.DateField(null=True, blank=True, verbose_name="Hedef Tarih")
    
    class Meta:
        verbose_name = "Migrasyon Hedefi"
        verbose_name_plural = "Migrasyon Hedefleri"
    
    def __str__(self):
        return self.name
    
    @property
    def completion_percentage(self):
        """Tamamlanma yüzdesi"""
        if self.target_count == 0:
            return 0
        return round((self.current_count / self.target_count) * 100, 1)
