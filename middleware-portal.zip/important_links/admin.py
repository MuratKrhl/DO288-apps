from django.contrib import admin
from django.utils.html import format_html
from django.urls import reverse
from django.utils.safestring import mark_safe
from .models import LinkCategory, ImportantLink, LinkAccessLog

@admin.register(LinkCategory)
class LinkCategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'get_icon_display', 'get_color_badge', 'link_count', 'order', 'is_active']
    list_filter = ['color', 'is_active', 'created_at']
    search_fields = ['name', 'description']
    list_editable = ['order', 'is_active']
    prepopulated_fields = {'name': ('name',)}
    
    fieldsets = (
        ('Temel Bilgiler', {
            'fields': ('name', 'description', 'is_active')
        }),
        ('Görünüm', {
            'fields': ('icon', 'color', 'order')
        }),
        ('Sistem Bilgileri', {
            'fields': ('created_at', 'updated_at', 'created_by', 'updated_by'),
            'classes': ('collapse',)
        }),
    )
    
    readonly_fields = ['created_at', 'updated_at', 'created_by', 'updated_by']
    
    def get_icon_display(self, obj):
        return format_html('<i class="{}"></i>', obj.icon)
    get_icon_display.short_description = 'İkon'
    
    def get_color_badge(self, obj):
        return format_html(
            '<span class="badge bg-{}">{}</span>',
            obj.color,
            obj.get_color_display()
        )
    get_color_badge.short_description = 'Renk'
    
    def link_count(self, obj):
        count = obj.links.filter(is_active=True).count()
        if count > 0:
            url = reverse('admin:important_links_importantlink_changelist')
            return format_html(
                '<a href="{}?category__id__exact={}">{} Link</a>',
                url, obj.id, count
            )
        return '0 Link'
    link_count.short_description = 'Link Sayısı'

class LinkAccessLogInline(admin.TabularInline):
    model = LinkAccessLog
    extra = 0
    readonly_fields = ['user', 'accessed_at', 'ip_address', 'user_agent']
    can_delete = False
    
    def has_add_permission(self, request, obj=None):
        return False

@admin.register(ImportantLink)
class ImportantLinkAdmin(admin.ModelAdmin):
    list_display = ['title', 'category', 'get_icon_display', 'get_url_link', 
                   'click_count', 'is_featured', 'requires_vpn', 'is_active']
    list_filter = ['category', 'is_featured', 'requires_vpn', 'is_internal', 'is_active', 'created_at']
    search_fields = ['title', 'description', 'url', 'tags']
    list_editable = ['order', 'is_featured', 'is_active']
    
    fieldsets = (
        ('Temel Bilgiler', {
            'fields': ('category', 'title', 'url', 'description', 'is_active')
        }),
        ('Görünüm', {
            'fields': ('icon', 'order', 'is_featured')
        }),
        ('Özellikler', {
            'fields': ('requires_vpn', 'is_internal', 'tags')
        }),
        ('İstatistikler', {
            'fields': ('click_count', 'last_clicked'),
            'classes': ('collapse',)
        }),
        ('Sistem Bilgileri', {
            'fields': ('created_at', 'updated_at', 'created_by', 'updated_by'),
            'classes': ('collapse',)
        }),
    )
    
    readonly_fields = ['click_count', 'last_clicked', 'created_at', 'updated_at', 'created_by', 'updated_by']
    inlines = [LinkAccessLogInline]
    
    def get_icon_display(self, obj):
        return format_html('<i class="{}"></i>', obj.icon)
    get_icon_display.short_description = 'İkon'
    
    def get_url_link(self, obj):
        return format_html(
            '<a href="{}" target="_blank" title="{}"><i class="ri-external-link-line"></i></a>',
            obj.url, obj.url
        )
    get_url_link.short_description = 'URL'
    
    actions = ['mark_as_featured', 'mark_as_not_featured', 'reset_click_counts']
    
    def mark_as_featured(self, request, queryset):
        updated = queryset.update(is_featured=True)
        self.message_user(request, f'{updated} link öne çıkan olarak işaretlendi.')
    mark_as_featured.short_description = 'Seçili linkleri öne çıkan yap'
    
    def mark_as_not_featured(self, request, queryset):
        updated = queryset.update(is_featured=False)
        self.message_user(request, f'{updated} link öne çıkan olmaktan çıkarıldı.')
    mark_as_not_featured.short_description = 'Seçili linkleri öne çıkan olmaktan çıkar'
    
    def reset_click_counts(self, request, queryset):
        updated = queryset.update(click_count=0, last_clicked=None)
        self.message_user(request, f'{updated} linkin tıklanma sayısı sıfırlandı.')
    reset_click_counts.short_description = 'Tıklanma sayılarını sıfırla'

@admin.register(LinkAccessLog)
class LinkAccessLogAdmin(admin.ModelAdmin):
    list_display = ['link', 'user', 'accessed_at', 'ip_address']
    list_filter = ['accessed_at', 'link__category']
    search_fields = ['link__title', 'user__username', 'ip_address']
    readonly_fields = ['link', 'user', 'accessed_at', 'ip_address', 'user_agent']
    date_hierarchy = 'accessed_at'
    
    def has_add_permission(self, request):
        return False
    
    def has_change_permission(self, request, obj=None):
        return False
