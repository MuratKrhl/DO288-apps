import requests
import pandas as pd
import json
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from django.utils import timezone
from django.conf import settings
from .models import DutySchedule, DutySyncSource, DutySyncLog
import logging

logger = logging.getLogger(__name__)

class DutySyncService:
    """Nöbet listesi senkronizasyon servisi"""
    
    def __init__(self):
        self.session = requests.Session()
        self.session.timeout = 30
    
    def sync_all_sources(self):
        """Tüm aktif kaynaklardan senkronizasyon"""
        sources = DutySyncSource.objects.filter(is_active=True)
        results = []
        
        for source in sources:
            try:
                result = self.sync_source(source)
                results.append(result)
            except Exception as e:
                logger.error(f"Kaynak senkronizasyon hatası {source.name}: {str(e)}")
                self.log_sync_result(source, 'error', 0, 0, 0, str(e))
        
        return results
    
    def sync_source(self, source):
        """Belirli bir kaynaktan senkronizasyon"""
        start_time = timezone.now()
        
        try:
            # Veriyi çek
            data = self.fetch_data(source)
            
            # Veriyi işle
            processed_data = self.process_data(data, source)
            
            # Veritabanını güncelle
            created, updated = self.update_database(processed_data)
            
            # Başarılı log
            execution_time = timezone.now() - start_time
            self.log_sync_result(
                source, 'success', 
                len(processed_data), created, updated, 
                execution_time=execution_time
            )
            
            # Son senkronizasyon zamanını güncelle
            source.last_sync = timezone.now()
            source.save()
            
            return {
                'source': source.name,
                'status': 'success',
                'processed': len(processed_data),
                'created': created,
                'updated': updated
            }
            
        except Exception as e:
            execution_time = timezone.now() - start_time
            self.log_sync_result(
                source, 'error', 0, 0, 0, str(e), execution_time
            )
            raise e
    
    def fetch_data(self, source):
        """Kaynaktan veri çekme"""
        # Authentication setup
        if source.auth_required:
            if source.username and source.password:
                self.session.auth = (source.username, source.password)
            elif source.api_key:
                self.session.headers.update({'Authorization': f'Bearer {source.api_key}'})
        
        # Custom headers
        if source.headers:
            self.session.headers.update(source.headers)
        
        # Fetch data
        response = self.session.get(source.url)
        response.raise_for_status()
        
        return response
    
    def process_data(self, response, source):
        """Veriyi işleme"""
        if source.source_type == 'csv':
            return self.process_csv(response, source)
        elif source.source_type == 'excel':
            return self.process_excel(response, source)
        elif source.source_type == 'json':
            return self.process_json(response, source)
        elif source.source_type == 'xml':
            return self.process_xml(response, source)
        else:
            raise ValueError(f"Desteklenmeyen kaynak tipi: {source.source_type}")
    
    def process_csv(self, response, source):
        """CSV veri işleme"""
        df = pd.read_csv(response.content.decode('utf-8'))
        return self.dataframe_to_duty_records(df, source)
    
    def process_excel(self, response, source):
        """Excel veri işleme"""
        df = pd.read_excel(response.content)
        return self.dataframe_to_duty_records(df, source)
    
    def process_json(self, response, source):
        """JSON veri işleme"""
        data = response.json()
        
        # JSON yapısına göre veri çıkarma
        if isinstance(data, list):
            records = data
        elif isinstance(data, dict) and 'data' in data:
            records = data['data']
        else:
            records = [data]
        
        processed_records = []
        for record in records:
            processed_record = self.map_fields(record, source.field_mapping)
            processed_records.append(processed_record)
        
        return processed_records
    
    def process_xml(self, response, source):
        """XML veri işleme"""
        root = ET.fromstring(response.content)
        records = []
        
        # XML yapısına göre kayıtları çıkar
        for item in root.findall('.//item'):  # Genel XML yapısı
            record = {}
            for child in item:
                record[child.tag] = child.text
            records.append(record)
        
        processed_records = []
        for record in records:
            processed_record = self.map_fields(record, source.field_mapping)
            processed_records.append(processed_record)
        
        return processed_records
    
    def dataframe_to_duty_records(self, df, source):
        """DataFrame'i nöbet kayıtlarına çevirme"""
        records = []
        
        for _, row in df.iterrows():
            record = self.map_fields(row.to_dict(), source.field_mapping)
            records.append(record)
        
        return records
    
    def map_fields(self, source_record, field_mapping):
        """Alan eşleştirme"""
        mapped_record = {}
        
        # Varsayılan eşleştirmeler
        default_mapping = {
            'date': ['date', 'tarih', 'gun', 'day'],
            'primary_person': ['primary_person', 'nobetci', 'ad_soyad', 'name'],
            'secondary_person': ['secondary_person', 'yedek', 'backup'],
            'phone': ['phone', 'telefon', 'tel'],
            'email': ['email', 'eposta', 'mail'],
            'department': ['department', 'departman', 'birim'],
            'notes': ['notes', 'notlar', 'aciklama'],
        }
        
        # Kullanıcı tanımlı eşleştirmeleri uygula
        if field_mapping:
            default_mapping.update(field_mapping)
        
        for target_field, source_fields in default_mapping.items():
            for source_field in source_fields:
                if source_field in source_record and source_record[source_field]:
                    mapped_record[target_field] = source_record[source_field]
                    break
        
        # Tarih formatını düzelt
        if 'date' in mapped_record:
            mapped_record['date'] = self.parse_date(mapped_record['date'])
        
        return mapped_record
    
    def parse_date(self, date_str):
        """Tarih string'ini parse etme"""
        if isinstance(date_str, datetime):
            return date_str.date()
        
        # Çeşitli tarih formatlarını dene
        date_formats = [
            '%Y-%m-%d',
            '%d.%m.%Y',
            '%d/%m/%Y',
            '%m/%d/%Y',
            '%Y/%m/%d',
            '%d-%m-%Y',
        ]
        
        for fmt in date_formats:
            try:
                return datetime.strptime(str(date_str), fmt).date()
            except ValueError:
                continue
        
        raise ValueError(f"Tarih formatı tanınamadı: {date_str}")
    
    def update_database(self, records):
        """Veritabanını güncelleme"""
        created_count = 0
        updated_count = 0
        
        for record in records:
            if 'date' not in record or not record['date']:
                continue
            
            # Hafta sonu ve tatil kontrolü
            date_obj = record['date']
            is_weekend = date_obj.weekday() >= 5  # Cumartesi=5, Pazar=6
            
            duty, created = DutySchedule.objects.update_or_create(
                date=date_obj,
                defaults={
                    'primary_person': record.get('primary_person', ''),
                    'secondary_person': record.get('secondary_person', ''),
                    'phone': record.get('phone', ''),
                    'email': record.get('email', ''),
                    'department': record.get('department', ''),
                    'notes': record.get('notes', ''),
                    'is_weekend': is_weekend,
                    'is_active': True,
                }
            )
            
            if created:
                created_count += 1
            else:
                updated_count += 1
        
        return created_count, updated_count
    
    def log_sync_result(self, source, status, processed, created, updated, 
                       error_message='', execution_time=None):
        """Senkronizasyon sonucunu logla"""
        DutySyncLog.objects.create(
            source=source,
            status=status,
            records_processed=processed,
            records_created=created,
            records_updated=updated,
            error_message=error_message,
            execution_time=execution_time
        )
