from django.urls import path
from . import views

app_name = 'important_links'

urlpatterns = [
    # Ana sayfa
    path('', views.ImportantLinksView.as_view(), name='links_list'),
    path('onemli-linkler/', views.ImportantLinksView.as_view(), name='links_list_tr'),
    
    # Kategori detayı
    path('category/<int:category_id>/', views.LinkCategoryDetailView.as_view(), name='category_detail'),
    
    # Link yönlendirme
    path('link/<int:link_id>/redirect/', views.link_redirect, name='link_redirect'),
    
    # API endpoints
    path('api/search/', views.search_links, name='search_links'),
    path('api/stats/', views.link_stats_api, name='link_stats'),
    
    # Legacy
    path('legacy/', views.important_links_legacy, name='legacy'),
]
