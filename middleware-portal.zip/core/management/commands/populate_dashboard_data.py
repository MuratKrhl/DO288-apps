from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from core.models import OnDutySchedule, ImportantLink
from inventory.models import Server, Application
from askgt.models import Question, Category
from announcements.models import Announcement
from django.utils import timezone
from datetime import timedelta
import random

class Command(BaseCommand):
    help = 'Dashboard için örnek veri oluştur'

    def handle(self, *args, **options):
        self.stdout.write('Dashboard örnek verileri oluşturuluyor...')
        
        # Nöbet listesi
        self.create_duty_schedule()
        
        # Önemli linkler
        self.create_important_links()
        
        # Örnek sunucular
        self.create_sample_servers()
        
        # Örnek uygulamalar
        self.create_sample_applications()
        
        self.stdout.write(
            self.style.SUCCESS('Dashboard örnek verileri başarıyla oluşturuldu!')
        )

    def create_duty_schedule(self):
        """Nöbet listesi oluştur"""
        today = timezone.now().date()
        
        duty_persons = [
            ('Ahmet Yılmaz', 'ahmet.yilmaz@company.com', '+90 555 123 4567'),
            ('Mehmet Demir', 'mehmet.demir@company.com', '+90 555 234 5678'),
            ('Ayşe Kaya', 'ayse.kaya@company.com', '+90 555 345 6789'),
            ('Fatma Şahin', 'fatma.sahin@company.com', '+90 555 456 7890'),
        ]
        
        for i in range(30):  # 30 günlük nöbet listesi
            date = today + timedelta(days=i)
            person = duty_persons[i % len(duty_persons)]
            
            OnDutySchedule.objects.get_or_create(
                date=date,
                defaults={
                    'primary_person': person[0],
                    'contact_info': f"Email: {person[1]}\nTelefon: {person[2]}",
                    'is_active': True
                }
            )

    def create_important_links(self):
        """Önemli linkler oluştur"""
        links = [
            ('Grafana', 'https://grafana.company.com', 'monitoring', 'ri-line-chart-line'),
            ('Prometheus', 'https://prometheus.company.com', 'monitoring', 'ri-pulse-line'),
            ('Jenkins', 'https://jenkins.company.com', 'tools', 'ri-settings-3-line'),
            ('GitLab', 'https://gitlab.company.com', 'tools', 'ri-git-branch-line'),
            ('Confluence', 'https://confluence.company.com', 'documentation', 'ri-book-line'),
            ('Jira', 'https://jira.company.com', 'tools', 'ri-bug-line'),
            ('Zabbix', 'https://zabbix.company.com', 'monitoring', 'ri-eye-line'),
            ('Nexus', 'https://nexus.company.com', 'tools', 'ri-archive-line'),
        ]
        
        for i, (title, url, category, icon) in enumerate(links):
            ImportantLink.objects.get_or_create(
                title=title,
                defaults={
                    'url': url,
                    'category': category,
                    'icon': icon,
                    'order': i,
                    'is_active': True
                }
            )

    def create_sample_servers(self):
        """Örnek sunucular oluştur"""
        if Server.objects.exists():
            return
        
        environments = ['prod', 'test', 'dev', 'stage']
        os_types = ['linux', 'aix', 'windows']
        locations = ['DC1', 'DC2', 'Cloud-AWS', 'Cloud-Azure']
        
        for i in range(20):
            Server.objects.create(
                hostname=f"srv-{random.choice(environments)}-{i+1:03d}",
                ip_address=f"10.{random.randint(1,254)}.{random.randint(1,254)}.{random.randint(1,254)}",
                operating_system=random.choice(os_types),
                environment=random.choice(environments),
                cpu_cores=random.choice([4, 8, 16, 32]),
                memory_gb=random.choice([8, 16, 32, 64, 128]),
                disk_gb=random.choice([100, 500, 1000, 2000]),
                location=random.choice(locations),
                description=f"Örnek sunucu {i+1}",
                is_active=True
            )

    def create_sample_applications(self):
        """Örnek uygulamalar oluştur"""
        if Application.objects.exists():
            return
        
        app_types = ['jboss', 'websphere', 'nginx', 'apache', 'hazelcast']
        servers = list(Server.objects.all())
        
        for i in range(50):
            server = random.choice(servers)
            app_type = random.choice(app_types)
            
            Application.objects.create(
                name=f"{app_type}-app-{i+1:03d}",
                application_type=app_type,
                version=f"{random.randint(1,3)}.{random.randint(0,9)}.{random.randint(0,9)}",
                server=server,
                port=random.choice([8080, 8443, 9080, 9443, 80, 443]),
                context_path=f"/{app_type}-app-{i+1}",
                config_path=f"/opt/{app_type}/config",
                log_path=f"/opt/{app_type}/logs",
                description=f"Örnek {app_type} uygulaması",
                is_active=True
            )
