from haystack import indexes
from inventory.models import Server, Application
from askgt.models import Question, Category
from announcements.models import Announcement

class ServerIndex(indexes.SearchIndex, indexes.Indexable):
    """Sunucu arama indeksi"""
    text = indexes.CharField(document=True, use_template=True)
    hostname = indexes.CharField(model_attr='hostname')
    ip_address = indexes.CharField(model_attr='ip_address')
    environment = indexes.CharField(model_attr='environment')
    operating_system = indexes.CharField(model_attr='operating_system')
    location = indexes.CharField(model_attr='location')
    created_at = indexes.DateTimeField(model_attr='created_at')
    
    def get_model(self):
        return Server
    
    def index_queryset(self, using=None):
        return self.get_model().objects.filter(is_active=True)

class ApplicationIndex(indexes.SearchIndex, indexes.Indexable):
    """Uygulama arama indeksi"""
    text = indexes.CharField(document=True, use_template=True)
    name = indexes.CharField(model_attr='name')
    application_type = indexes.CharField(model_attr='application_type')
    version = indexes.CharField(model_attr='version')
    server_hostname = indexes.CharField(model_attr='server__hostname')
    created_at = indexes.DateTimeField(model_attr='created_at')
    
    def get_model(self):
        return Application
    
    def index_queryset(self, using=None):
        return self.get_model().objects.filter(is_active=True).select_related('server')

class QuestionIndex(indexes.SearchIndex, indexes.Indexable):
    """Soru arama indeksi"""
    text = indexes.CharField(document=True, use_template=True)
    title = indexes.CharField(model_attr='title')
    question = indexes.CharField(model_attr='question')
    answer = indexes.CharField(model_attr='answer')
    category = indexes.CharField(model_attr='category__name')
    tags = indexes.CharField(model_attr='tags')
    priority = indexes.CharField(model_attr='priority')
    is_featured = indexes.BooleanField(model_attr='is_featured')
    created_at = indexes.DateTimeField(model_attr='created_at')
    
    def get_model(self):
        return Question
    
    def index_queryset(self, using=None):
        return self.get_model().objects.filter(is_active=True).select_related('category')

class AnnouncementIndex(indexes.SearchIndex, indexes.Indexable):
    """Duyuru arama indeksi"""
    text = indexes.CharField(document=True, use_template=True)
    title = indexes.CharField(model_attr='title')
    content = indexes.CharField(model_attr='content')
    announcement_type = indexes.CharField(model_attr='announcement_type')
    is_urgent = indexes.BooleanField(model_attr='is_urgent')
    is_pinned = indexes.BooleanField(model_attr='is_pinned')
    start_date = indexes.DateTimeField(model_attr='start_date')
    
    def get_model(self):
        return Announcement
    
    def index_queryset(self, using=None):
        return self.get_model().objects.filter(is_active=True)
