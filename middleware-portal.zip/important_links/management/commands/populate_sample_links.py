from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from important_links.models import LinkCategory, ImportantLink

class Command(BaseCommand):
    help = 'Örnek link kategorileri ve linkleri oluşturur'

    def handle(self, *args, **options):
        # Admin kullanıcısını al
        try:
            admin_user = User.objects.filter(is_superuser=True).first()
        except:
            admin_user = None

        # Kategoriler oluştur
        categories_data = [
            {
                'name': 'Monitoring & Alerting',
                'description': 'Sistem izleme ve uyarı araçları',
                'icon': 'ri-dashboard-line',
                'color': 'primary',
                'order': 1,
            },
            {
                'name': 'Dokümantasyon',
                'description': 'Teknik dokümantasyon ve kılavuzlar',
                'icon': 'ri-book-line',
                'color': 'success',
                'order': 2,
            },
            {
                'name': 'Geliştirme Araçları',
                'description': 'Yazılım geliştirme ve versiyon kontrol araçları',
                'icon': 'ri-code-line',
                'color': 'info',
                'order': 3,
            },
            {
                'name': 'Veritabanı Yönetimi',
                'description': 'Veritabanı yönetim araçları',
                'icon': 'ri-database-line',
                'color': 'warning',
                'order': 4,
            },
            {
                'name': 'Güvenlik',
                'description': 'Güvenlik araçları ve platformları',
                'icon': 'ri-shield-line',
                'color': 'danger',
                'order': 5,
            },
            {
                'name': 'İletişim & Collaboration',
                'description': 'İletişim ve işbirliği araçları',
                'icon': 'ri-team-line',
                'color': 'secondary',
                'order': 6,
            },
        ]

        categories = {}
        for cat_data in categories_data:
            category, created = LinkCategory.objects.get_or_create(
                name=cat_data['name'],
                defaults={
                    'description': cat_data['description'],
                    'icon': cat_data['icon'],
                    'color': cat_data['color'],
                    'order': cat_data['order'],
                    'created_by': admin_user,
                }
            )
            categories[cat_data['name']] = category
            
            if created:
                self.stdout.write(
                    self.style.SUCCESS(f'Kategori oluşturuldu: {category.name}')
                )

        # Linkler oluştur
        links_data = [
            # Monitoring & Alerting
            {
                'category': 'Monitoring & Alerting',
                'title': 'Dynatrace',
                'url': 'https://dynatrace.example.com',
                'description': 'Uygulama performans izleme ve analiz platformu',
                'icon': 'ri-pulse-line',
                'is_featured': True,
                'requires_vpn': True,
                'tags': 'monitoring, apm, performance',
                'order': 1,
            },
            {
                'category': 'Monitoring & Alerting',
                'title': 'Grafana',
                'url': 'https://grafana.example.com',
                'description': 'Metrik görselleştirme ve dashboard platformu',
                'icon': 'ri-bar-chart-line',
                'is_featured': True,
                'requires_vpn': True,
                'tags': 'monitoring, dashboard, metrics',
                'order': 2,
            },
            {
                'category': 'Monitoring & Alerting',
                'title': 'Prometheus',
                'url': 'https://prometheus.example.com',
                'description': 'Metrik toplama ve uyarı sistemi',
                'icon': 'ri-alarm-line',
                'requires_vpn': True,
                'tags': 'monitoring, metrics, alerting',
                'order': 3,
            },
            {
                'category': 'Monitoring & Alerting',
                'title': 'Splunk',
                'url': 'https://splunk.example.com',
                'description': 'Log analizi ve güvenlik izleme platformu',
                'icon': 'ri-search-eye-line',
                'requires_vpn': True,
                'tags': 'logging, security, analysis',
                'order': 4,
            },
            {
                'category': 'Monitoring & Alerting',
                'title': 'Kibana',
                'url': 'https://kibana.example.com',
                'description': 'Elasticsearch veri görselleştirme aracı',
                'icon': 'ri-pie-chart-line',
                'requires_vpn': True,
                'tags': 'elasticsearch, visualization, logs',
                'order': 5,
            },

            # Dokümantasyon
            {
                'category': 'Dokümantasyon',
                'title': 'Confluence',
                'url': 'https://confluence.example.com',
                'description': 'Kurumsal wiki ve dokümantasyon platformu',
                'icon': 'ri-file-text-line',
                'is_featured': True,
                'requires_vpn': True,
                'tags': 'documentation, wiki, collaboration',
                'order': 1,
            },
            {
                'category': 'Dokümantasyon',
                'title': 'GitBook',
                'url': 'https://gitbook.example.com',
                'description': 'Modern dokümantasyon ve bilgi paylaşım platformu',
                'icon': 'ri-book-open-line',
                'tags': 'documentation, knowledge, sharing',
                'order': 2,
            },
            {
                'category': 'Dokümantasyon',
                'title': 'API Documentation',
                'url': 'https://api-docs.example.com',
                'description': 'REST API dokümantasyonu ve test arayüzü',
                'icon': 'ri-code-s-slash-line',
                'requires_vpn': True,
                'tags': 'api, documentation, swagger',
                'order': 3,
            },

            # Geliştirme Araçları
            {
                'category': 'Geliştirme Araçları',
                'title': 'GitLab',
                'url': 'https://gitlab.example.com',
                'description': 'Git repository yönetimi ve CI/CD platformu',
                'icon': 'ri-git-branch-line',
                'is_featured': True,
                'requires_vpn': True,
                'tags': 'git, cicd, development',
                'order': 1,
            },
            {
                'category': 'Geliştirme Araçları',
                'title': 'Jenkins',
                'url': 'https://jenkins.example.com',
                'description': 'Sürekli entegrasyon ve deployment aracı',
                'icon': 'ri-settings-4-line',
                'requires_vpn': True,
                'tags': 'cicd, automation, deployment',
                'order': 2,
            },
            {
                'category': 'Geliştirme Araçları',
                'title': 'SonarQube',
                'url': 'https://sonarqube.example.com',
                'description': 'Kod kalitesi analizi ve güvenlik tarama',
                'icon': 'ri-bug-line',
                'requires_vpn': True,
                'tags': 'code quality, security, analysis',
                'order': 3,
            },

            # Veritabanı Yönetimi
            {
                'category': 'Veritabanı Yönetimi',
                'title': 'phpMyAdmin',
                'url': 'https://phpmyadmin.example.com',
                'description': 'MySQL veritabanı yönetim arayüzü',
                'icon': 'ri-database-2-line',
                'requires_vpn': True,
                'tags': 'mysql, database, management',
                'order': 1,
            },
            {
                'category': 'Veritabanı Yönetimi',
                'title': 'MongoDB Compass',
                'url': 'https://mongodb.example.com',
                'description': 'MongoDB veritabanı görsel yönetim aracı',
                'icon': 'ri-leaf-line',
                'requires_vpn': True,
                'tags': 'mongodb, nosql, database',
                'order': 2,
            },
            {
                'category': 'Veritabanı Yönetimi',
                'title': 'Redis Commander',
                'url': 'https://redis.example.com',
                'description': 'Redis cache yönetim arayüzü',
                'icon': 'ri-flashlight-line',
                'requires_vpn': True,
                'tags': 'redis, cache, memory',
                'order': 3,
            },

            # Güvenlik
            {
                'category': 'Güvenlik',
                'title': 'Vault',
                'url': 'https://vault.example.com',
                'description': 'Gizli bilgi ve sertifika yönetimi',
                'icon': 'ri-safe-line',
                'is_featured': True,
                'requires_vpn': True,
                'tags': 'security, secrets, certificates',
                'order': 1,
            },
            {
                'category': 'Güvenlik',
                'title': 'LDAP Admin',
                'url': 'https://ldap.example.com',
                'description': 'LDAP kullanıcı ve grup yönetimi',
                'icon': 'ri-user-settings-line',
                'requires_vpn': True,
                'tags': 'ldap, users, authentication',
                'order': 2,
            },

            # İletişim & Collaboration
            {
                'category': 'İletişim & Collaboration',
                'title': 'Slack',
                'url': 'https://workspace.slack.com',
                'description': 'Takım iletişimi ve işbirliği platformu',
                'icon': 'ri-slack-line',
                'is_internal': False,
                'tags': 'communication, team, collaboration',
                'order': 1,
            },
            {
                'category': 'İletişim & Collaboration',
                'title': 'Microsoft Teams',
                'url': 'https://teams.microsoft.com',
                'description': 'Video konferans ve takım çalışması',
                'icon': 'ri-microsoft-line',
                'is_internal': False,
                'tags': 'video, meeting, collaboration',
                'order': 2,
            },
            {
                'category': 'İletişim & Collaboration',
                'title': 'Jira',
                'url': 'https://jira.example.com',
                'description': 'Proje yönetimi ve issue tracking',
                'icon': 'ri-task-line',
                'requires_vpn': True,
                'tags': 'project management, issues, agile',
                'order': 3,
            },
        ]

        # Linkleri oluştur
        for link_data in links_data:
            category = categories[link_data['category']]
            
            link, created = ImportantLink.objects.get_or_create(
                category=category,
                title=link_data['title'],
                defaults={
                    'url': link_data['url'],
                    'description': link_data['description'],
                    'icon': link_data['icon'],
                    'is_featured': link_data.get('is_featured', False),
                    'requires_vpn': link_data.get('requires_vpn', False),
                    'is_internal': link_data.get('is_internal', True),
                    'tags': link_data.get('tags', ''),
                    'order': link_data['order'],
                    'created_by': admin_user,
                }
            )
            
            if created:
                self.stdout.write(
                    self.style.SUCCESS(f'Link oluşturuldu: {link.title}')
                )

        self.stdout.write(
            self.style.SUCCESS('Örnek linkler başarıyla oluşturuldu!')
        )
