from django.core.management.base import BaseCommand
from django.utils import timezone
from core.models import MigrationTarget
from inventory.models import Application

class Command(BaseCommand):
    help = 'JBoss 8 migrasyon istatistiklerini güncelle'

    def handle(self, *args, **options):
        self.stdout.write('JBoss 8 migrasyon istatistikleri güncelleniyor...')
        
        # JBoss 8 migrasyon hedefini bul veya oluştur
        migration_target, created = MigrationTarget.objects.get_or_create(
            name='JBoss 8 Migration',
            defaults={
                'description': 'JBoss uygulamalarının JBoss 8 platformuna geçiş projesi',
                'target_count': 100,  # Hedef sayı
                'deadline': timezone.now().date().replace(month=12, day=31),  # Yıl sonu hedefi
                'is_active': True
            }
        )
        
        # Mevcut JBoss 8 uygulama sayısını hesapla
        current_jboss8_count = Application.objects.filter(
            is_active=True,
            application_type='jboss',
            version__icontains='8'
        ).count()
        
        # Hedefi güncelle
        migration_target.current_count = current_jboss8_count
        migration_target.save()
        
        self.stdout.write(
            self.style.SUCCESS(
                f'JBoss 8 migrasyon istatistikleri güncellendi: '
                f'{current_jboss8_count}/{migration_target.target_count} '
                f'(%{migration_target.completion_percentage:.1f})'
            )
        )
