from django.utils import timezone
from .models import OnDutySchedule, ImportantLink

def global_context(request):
    """Global template context"""
    today = timezone.now().date()
    
    # Bugünkü nöbetçi
    today_duty = OnDutySchedule.objects.filter(
        date=today, 
        is_active=True
    ).first()
    
    # Önemli linkler
    important_links = ImportantLink.objects.filter(
        is_active=True
    ).order_by('category', 'order')
    
    return {
        'today_duty': today_duty,
        'important_links': important_links,
        'current_year': today.year,
    }
