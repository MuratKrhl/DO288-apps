from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import TemplateView, ListView
from django.http import JsonResponse, HttpResponseRedirect
from django.db.models import Count, Q
from django.core.cache import cache
from django.utils import timezone
from django.contrib import messages
from .models import LinkCategory, ImportantLink, LinkAccessLog
import json

class ImportantLinksView(LoginRequiredMixin, TemplateView):
    """Ana önemli linkler sayfası"""
    template_name = 'important_links/important_links.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Cache kontrolü
        cache_key = f"important_links_data_{self.request.user.id}"
        cached_data = cache.get(cache_key)
        
        if cached_data:
            context.update(cached_data)
        else:
            # Veri toplama
            links_data = self.get_links_data()
            cache.set(cache_key, links_data, 600)  # 10 dakika cache
            context.update(links_data)
        
        return context
    
    def get_links_data(self):
        """Link verilerini topla"""
        # Kategoriler ve linkleri getir
        categories = LinkCategory.objects.filter(
            is_active=True
        ).prefetch_related(
            'links__access_logs'
        ).annotate(
            active_link_count=Count('links', filter=Q(links__is_active=True))
        ).order_by('order', 'name')
        
        # Öne çıkan linkler
        featured_links = ImportantLink.objects.filter(
            is_active=True,
            is_featured=True
        ).select_related('category').order_by('-click_count')[:6]
        
        # En çok tıklanan linkler
        popular_links = ImportantLink.objects.filter(
            is_active=True
        ).select_related('category').order_by('-click_count')[:8]
        
        # Son eklenen linkler
        recent_links = ImportantLink.objects.filter(
            is_active=True
        ).select_related('category').order_by('-created_at')[:5]
        
        # İstatistikler
        stats = {
            'total_categories': categories.count(),
            'total_links': ImportantLink.objects.filter(is_active=True).count(),
            'total_clicks': ImportantLink.objects.filter(is_active=True).aggregate(
                total=models.Sum('click_count')
            )['total'] or 0,
            'vpn_required_links': ImportantLink.objects.filter(
                is_active=True, requires_vpn=True
            ).count(),
        }
        
        return {
            'categories': categories,
            'featured_links': featured_links,
            'popular_links': popular_links,
            'recent_links': recent_links,
            'stats': stats,
        }

class LinkCategoryDetailView(LoginRequiredMixin, TemplateView):
    """Kategori detay sayfası"""
    template_name = 'important_links/category_detail.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        category_id = kwargs.get('category_id')
        
        category = get_object_or_404(LinkCategory, id=category_id, is_active=True)
        links = category.get_active_links()
        
        context.update({
            'category': category,
            'links': links,
            'link_count': links.count(),
        })
        
        return context

@login_required
def link_redirect(request, link_id):
    """Link yönlendirme ve istatistik güncelleme"""
    link = get_object_or_404(ImportantLink, id=link_id, is_active=True)
    
    # Tıklanma sayısını artır
    link.increment_click_count()
    
    # Erişim logunu kaydet
    LinkAccessLog.objects.create(
        link=link,
        user=request.user,
        ip_address=get_client_ip(request),
        user_agent=request.META.get('HTTP_USER_AGENT', '')
    )
    
    # Cache'i temizle
    cache_key = f"important_links_data_{request.user.id}"
    cache.delete(cache_key)
    
    return HttpResponseRedirect(link.url)

@login_required
def search_links(request):
    """Link arama API"""
    query = request.GET.get('q', '').strip()
    
    if not query:
        return JsonResponse({'results': []})
    
    # Arama yap
    links = ImportantLink.objects.filter(
        Q(title__icontains=query) |
        Q(description__icontains=query) |
        Q(tags__icontains=query) |
        Q(category__name__icontains=query),
        is_active=True
    ).select_related('category')[:20]
    
    # Sonuçları hazırla
    results = []
    for link in links:
        results.append({
            'id': link.id,
            'title': link.title,
            'description': link.description,
            'url': link.url,
            'category': {
                'name': link.category.name,
                'color': link.category.color,
                'icon': link.category.icon,
            },
            'icon': link.icon,
            'requires_vpn': link.requires_vpn,
            'is_internal': link.is_internal,
            'click_count': link.click_count,
        })
    
    return JsonResponse({
        'results': results,
        'count': len(results),
        'query': query,
    })

@login_required
def link_stats_api(request):
    """Link istatistikleri API"""
    # Genel istatistikler
    stats = {
        'total_links': ImportantLink.objects.filter(is_active=True).count(),
        'total_categories': LinkCategory.objects.filter(is_active=True).count(),
        'total_clicks': ImportantLink.objects.filter(is_active=True).aggregate(
            total=models.Sum('click_count')
        )['total'] or 0,
        'featured_links': ImportantLink.objects.filter(
            is_active=True, is_featured=True
        ).count(),
    }
    
    # Kategori bazlı istatistikler
    category_stats = []
    categories = LinkCategory.objects.filter(is_active=True).annotate(
        link_count=Count('links', filter=Q(links__is_active=True)),
        total_clicks=models.Sum('links__click_count', filter=Q(links__is_active=True))
    )
    
    for category in categories:
        category_stats.append({
            'name': category.name,
            'link_count': category.link_count,
            'total_clicks': category.total_clicks or 0,
            'color': category.color,
        })
    
    return JsonResponse({
        'stats': stats,
        'category_stats': category_stats,
    })

def get_client_ip(request):
    """İstemci IP adresini al"""
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip

# Legacy view (compatibility)
@login_required
def important_links_legacy(request):
    """Eski important links view - yönlendirme"""
    return redirect('important_links:links_list')
