from django.apps import AppConfig

class ImportantLinksConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'important_links'
    verbose_name = 'Önemli Linkler'
