from django.urls import path
from . import views

app_name = 'core'

urlpatterns = [
    # Main dashboard
    path('', views.DashboardView.as_view(), name='dashboard'),
    path('dashboard/', views.DashboardView.as_view(), name='dashboard_detail'),
    
    # Search
    path('search/', views.search_results, name='search_results'),
    
    # Dashboard AJAX APIs
    path('api/dashboard/summary/', views.dashboard_summary_api, name='dashboard_summary_api'),
    path('api/dashboard/performance/', views.dashboard_performance_api, name='dashboard_performance_api'),
    path('api/dashboard/inventory/', views.dashboard_inventory_api, name='dashboard_inventory_api'),
    path('api/dashboard/activities/', views.dashboard_activities_api, name='dashboard_activities_api'),
    path('api/dashboard/jboss8/', views.dashboard_jboss8_api, name='dashboard_jboss8_api'),
]
