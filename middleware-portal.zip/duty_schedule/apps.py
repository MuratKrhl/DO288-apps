from django.apps import AppConfig

class DutyScheduleConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'duty_schedule'
    verbose_name = 'Nöbet Listesi'
    
    def ready(self):
        import duty_schedule.signals
