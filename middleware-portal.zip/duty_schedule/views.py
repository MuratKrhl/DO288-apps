from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import ListView, DetailView
from django.core.paginator import Paginator
from django.db.models import Q
from django.http import JsonResponse
from django.utils import timezone
from datetime import datetime, timedelta
from .models import DutySchedule, DutySyncLog
from .services import DutySyncService
import calendar

class DutyScheduleListView(LoginRequiredMixin, ListView):
    """Nöbet listesi görünümü"""
    model = DutySchedule
    template_name = 'duty_schedule/duty_list.html'
    context_object_name = 'duties'
    paginate_by = 50
    
    def get_queryset(self):
        queryset = DutySchedule.objects.filter(is_active=True)
        
        # Filtreleme
        search = self.request.GET.get('search')
        month = self.request.GET.get('month')
        year = self.request.GET.get('year')
        person = self.request.GET.get('person')
        
        if search:
            queryset = queryset.filter(
                Q(primary_person__icontains=search) |
                Q(secondary_person__icontains=search) |
                Q(department__icontains=search) |
                Q(notes__icontains=search)
            )
        
        if month and year:
            queryset = queryset.filter(date__year=year, date__month=month)
        elif year:
            queryset = queryset.filter(date__year=year)
        
        if person:
            queryset = queryset.filter(
                Q(primary_person__icontains=person) |
                Q(secondary_person__icontains=person)
            )
        
        return queryset.order_by('-date')
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Filtreleme parametreleri
        context['search'] = self.request.GET.get('search', '')
        context['month'] = self.request.GET.get('month', '')
        context['year'] = self.request.GET.get('year', '')
        context['person'] = self.request.GET.get('person', '')
        
        # Yıl ve ay seçenekleri
        current_year = timezone.now().year
        context['years'] = range(current_year - 2, current_year + 2)
        context['months'] = [
            (i, calendar.month_name[i]) for i in range(1, 13)
        ]
        
        # İstatistikler
        context['stats'] = self.get_statistics()
        
        # Bugünkü nöbetçi
        context['today_duty'] = DutySchedule.objects.filter(
            date=timezone.now().date(),
            is_active=True
        ).first()
        
        return context
    
    def get_statistics(self):
        """İstatistik bilgileri"""
        now = timezone.now()
        current_month = now.month
        current_year = now.year
        
        # Bu ay
        this_month = DutySchedule.objects.filter(
            date__year=current_year,
            date__month=current_month,
            is_active=True
        )
        
        # Gelecek ay
        next_month = current_month + 1 if current_month < 12 else 1
        next_year = current_year if current_month < 12 else current_year + 1
        
        next_month_duties = DutySchedule.objects.filter(
            date__year=next_year,
            date__month=next_month,
            is_active=True
        )
        
        return {
            'total_duties': DutySchedule.objects.filter(is_active=True).count(),
            'this_month': this_month.count(),
            'next_month': next_month_duties.count(),
            'weekend_duties': this_month.filter(is_weekend=True).count(),
            'holiday_duties': this_month.filter(is_holiday=True).count(),
        }

@login_required
def duty_calendar_view(request):
    """Nöbet takvimi görünümü"""
    year = int(request.GET.get('year', timezone.now().year))
    month = int(request.GET.get('month', timezone.now().month))
    
    # Ay başı ve sonu
    first_day = datetime(year, month, 1).date()
    if month == 12:
        last_day = datetime(year + 1, 1, 1).date() - timedelta(days=1)
    else:
        last_day = datetime(year, month + 1, 1).date() - timedelta(days=1)
    
    # Nöbet kayıtları
    duties = DutySchedule.objects.filter(
        date__range=[first_day, last_day],
        is_active=True
    ).order_by('date')
    
    # Takvim verisi hazırla
    cal = calendar.monthcalendar(year, month)
    duty_dict = {duty.date.day: duty for duty in duties}
    
    context = {
        'year': year,
        'month': month,
        'month_name': calendar.month_name[month],
        'calendar': cal,
        'duties': duty_dict,
        'prev_month': month - 1 if month > 1 else 12,
        'prev_year': year if month > 1 else year - 1,
        'next_month': month + 1 if month < 12 else 1,
        'next_year': year if month < 12 else year + 1,
    }
    
    return render(request, 'duty_schedule/duty_calendar.html', context)

@login_required
def duty_detail_view(request, pk):
    """Nöbet detay görünümü"""
    duty = get_object_or_404(DutySchedule, pk=pk, is_active=True)
    
    # Önceki ve sonraki nöbetler
    prev_duty = DutySchedule.objects.filter(
        date__lt=duty.date,
        is_active=True
    ).order_by('-date').first()
    
    next_duty = DutySchedule.objects.filter(
        date__gt=duty.date,
        is_active=True
    ).order_by('date').first()
    
    context = {
        'duty': duty,
        'prev_duty': prev_duty,
        'next_duty': next_duty,
    }
    
    return render(request, 'duty_schedule/duty_detail.html', context)

# API Views
@login_required
def duty_api_list(request):
    """Nöbet listesi API"""
    duties = DutySchedule.objects.filter(is_active=True).order_by('-date')
    
    # Filtreleme
    search = request.GET.get('search')
    if search:
        duties = duties.filter(
            Q(primary_person__icontains=search) |
            Q(secondary_person__icontains=search)
        )
    
    # Sayfalama
    page = int(request.GET.get('page', 1))
    per_page = int(request.GET.get('per_page', 20))
    
    paginator = Paginator(duties, per_page)
    page_obj = paginator.get_page(page)
    
    data = {
        'duties': [
            {
                'id': duty.id,
                'date': duty.date.strftime('%Y-%m-%d'),
                'date_display': duty.date.strftime('%d.%m.%Y'),
                'day_name': duty.day_name,
                'primary_person': duty.primary_person,
                'secondary_person': duty.secondary_person,
                'phone': duty.phone,
                'email': duty.email,
                'department': duty.department,
                'is_today': duty.is_today,
                'is_weekend': duty.is_weekend,
                'is_holiday': duty.is_holiday,
                'status_color': duty.status_color,
            }
            for duty in page_obj
        ],
        'pagination': {
            'current_page': page_obj.number,
            'total_pages': paginator.num_pages,
            'total_count': paginator.count,
            'has_next': page_obj.has_next(),
            'has_previous': page_obj.has_previous(),
        }
    }
    
    return JsonResponse(data)

@login_required
def today_duty_api(request):
    """Bugünkü nöbetçi API"""
    today_duty = DutySchedule.objects.filter(
        date=timezone.now().date(),
        is_active=True
    ).first()
    
    if today_duty:
        data = {
            'id': today_duty.id,
            'date': today_duty.date.strftime('%Y-%m-%d'),
            'primary_person': today_duty.primary_person,
            'secondary_person': today_duty.secondary_person,
            'phone': today_duty.phone,
            'email': today_duty.email,
            'department': today_duty.department,
            'day_name': today_duty.day_name,
        }
    else:
        data = None
    
    return JsonResponse({'today_duty': data})

@login_required
def sync_logs_view(request):
    """Senkronizasyon logları"""
    logs = DutySyncLog.objects.all().order_by('-created_at')[:50]
    
    context = {
        'logs': logs,
    }
    
    return render(request, 'duty_schedule/sync_logs.html', context)
