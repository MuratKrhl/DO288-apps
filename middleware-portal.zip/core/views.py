from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import TemplateView
from django.db.models import Count, Q, Avg
from django.utils import timezone
from django.core.cache import cache
from django.http import JsonResponse
from datetime import timedelta, datetime
from haystack.query import SearchQuerySet
from inventory.models import Server, Application
from askgt.models import Question, Category
from announcements.models import Announcement
from automation.models import AutomationTask
from performance.models import MetricData, Alert
from .models import OnDutySchedule, ImportantLink, MigrationTarget
import json

class DashboardView(LoginRequiredMixin, TemplateView):
    """Ana dashboard view - Class-based view ile performanslı veri toplama"""
    template_name = 'core/dashboard.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Cache anahtarları
        cache_key = f"dashboard_data_{self.request.user.id}"
        cached_data = cache.get(cache_key)
        
        if cached_data:
            context.update(cached_data)
        else:
            # Veri toplama ve cache'leme
            dashboard_data = self.collect_dashboard_data()
            cache.set(cache_key, dashboard_data, 300)  # 5 dakika cache
            context.update(dashboard_data)
        
        return context
    
    def collect_dashboard_data(self):
        """Dashboard verilerini topla"""
        now = timezone.now()
        today = now.date()
        week_ago = now - timedelta(days=7)
        
        # 1. Üst Sıra Özet Kartları (JBoss 8 dahil)
        summary_cards = self.get_summary_cards()
        
        # 2. Performans Metrikleri (Son 24 saat)
        performance_data = self.get_performance_data()
        
        # 3. Envanter Sağlık Durumu
        inventory_health = self.get_inventory_health()
        
        # 4. Son Duyurular
        recent_announcements = self.get_recent_announcements()
        
        # 5. Son AskGT Makaleleri
        recent_questions = self.get_recent_questions()
        
        # 6. Sistem Aktiviteleri
        system_activities = self.get_system_activities()
        
        # 7. Hızlı Erişim Linkleri
        quick_links = self.get_quick_links()
        
        # 8. JBoss 8 Migrasyon İstatistikleri
        jboss8_stats = self.get_jboss8_migration_stats()
        
        return {
            'summary_cards': summary_cards,
            'performance_data': performance_data,
            'inventory_health': inventory_health,
            'recent_announcements': recent_announcements,
            'recent_questions': recent_questions,
            'system_activities': system_activities,
            'quick_links': quick_links,
            'jboss8_stats': jboss8_stats,
        }
    
    def get_summary_cards(self):
        """Üst sıra özet kartları - JBoss 8 dahil"""
        # Toplam ve aktif uygulama sayıları
        total_applications = Application.objects.filter(is_active=True).count()
        active_applications = Application.objects.filter(is_active=True, status='running').count()
        
        # JBoss 8 uygulamaları
        jboss8_applications = Application.objects.filter(
            is_active=True,
            application_type='jboss',
            version__icontains='8'
        ).count()
        
        # Toplam JBoss uygulamaları
        total_jboss_applications = Application.objects.filter(
            is_active=True,
            application_type='jboss'
        ).count()
        
        # JBoss 8 migrasyon yüzdesi
        jboss8_percentage = 0
        if total_jboss_applications > 0:
            jboss8_percentage = round((jboss8_applications / total_jboss_applications) * 100, 1)
        
        # Sorunlu uygulamalar
        problematic_apps = Application.objects.filter(
            is_active=True, 
            status__in=['error', 'stopped']
        ).count()
        
        # Bugünkü nöbetçi
        today_duty = OnDutySchedule.objects.filter(
            date=timezone.now().date(),
            is_active=True
        ).first()
        
        # Toplam sunucu sayısı
        total_servers = Server.objects.filter(is_active=True).count()
        
        # Aktif uyarılar
        try:
            active_alerts = Alert.objects.filter(status='active').count()
        except:
            active_alerts = 0
        
        return {
            'total_applications': total_applications,
            'active_applications': active_applications,
            'problematic_apps': problematic_apps,
            'today_duty': today_duty,
            'total_servers': total_servers,
            'active_alerts': active_alerts,
            'jboss8_applications': jboss8_applications,
            'total_jboss_applications': total_jboss_applications,
            'jboss8_percentage': jboss8_percentage,
        }
    
    def get_jboss8_migration_stats(self):
        """JBoss 8 migrasyon istatistikleri"""
        # Migrasyon hedefi
        migration_target = MigrationTarget.objects.filter(
            name__icontains='JBoss 8',
            is_active=True
        ).first()
        
        # JBoss uygulamaları migrasyon durumuna göre
        jboss_apps = Application.objects.filter(
            is_active=True,
            application_type='jboss'
        )
        
        migration_stats = {
            'completed': jboss_apps.filter(version__icontains='8').count(),
            'in_progress': jboss_apps.filter(migration_status='in_progress').count(),
            'not_started': jboss_apps.filter(migration_status='not_started').count(),
            'failed': jboss_apps.filter(migration_status='failed').count(),
            'total': jboss_apps.count(),
        }
        
        # Hedef bilgileri
        if migration_target:
            migration_stats['target_count'] = migration_target.target_count
            migration_stats['target_percentage'] = migration_target.completion_percentage
            migration_stats['deadline'] = migration_target.deadline
        else:
            migration_stats['target_count'] = migration_stats['total']
            migration_stats['target_percentage'] = 0
            migration_stats['deadline'] = None
        
        return migration_stats
    
    def get_performance_data(self):
        """Son 24 saatlik performans verileri"""
        last_24h = timezone.now() - timedelta(hours=24)
        
        # Örnek performans verileri (gerçek implementasyon performance modülünden gelecek)
        performance_data = {
            'labels': [],
            'datasets': [{
                'label': 'Ortalama Yanıt Süresi (ms)',
                'data': [],
                'borderColor': 'rgb(64, 81, 137)',
                'backgroundColor': 'rgba(64, 81, 137, 0.1)',
                'tension': 0.4
            }]
        }
        
        # Son 24 saati 2 saatlik dilimler halinde böl
        for i in range(12):
            time_point = last_24h + timedelta(hours=i*2)
            performance_data['labels'].append(time_point.strftime('%H:%M'))
            # Örnek veri - gerçek implementasyonda MetricData'dan gelecek
            performance_data['datasets'][0]['data'].append(150 + (i * 10))
        
        return performance_data
    
    def get_inventory_health(self):
        """Envanter sağlık durumu dağılımı"""
        # Sunucu durumları
        server_stats = Server.objects.filter(is_active=True).values('environment').annotate(
            count=Count('id')
        )
        
        # Uygulama tipleri
        app_stats = Application.objects.filter(is_active=True).values('application_type').annotate(
            count=Count('id')
        )
        
        # Donut chart için veri hazırla
        health_data = {
            'servers': {
                'labels': [stat['environment'].title() for stat in server_stats],
                'data': [stat['count'] for stat in server_stats],
                'backgroundColor': [
                    '#405189',  # Production - Koyu mavi
                    '#0ab39c',  # Test - Yeşil
                    '#f7b84b',  # Development - Sarı
                    '#f06548',  # Staging - Kırmızı
                ]
            },
            'applications': {
                'labels': [stat['application_type'].title() for stat in app_stats],
                'data': [stat['count'] for stat in app_stats],
                'backgroundColor': [
                    '#405189', '#0ab39c', '#f7b84b', '#f06548', 
                    '#299cdb', '#74788d', '#6f42c1'
                ]
            }
        }
        
        return health_data
    
    def get_recent_announcements(self):
        """Son 5 duyuru"""
        now = timezone.now()
        announcements = Announcement.objects.filter(
            is_active=True,
            start_date__lte=now
        ).filter(
            Q(end_date__isnull=True) | Q(end_date__gte=now)
        ).order_by('-start_date')[:5]
        
        # JSON serializable hale getir
        announcements_data = []
        for announcement in announcements:
            announcements_data.append({
                'id': announcement.id,
                'title': announcement.title,
                'announcement_type': announcement.announcement_type,
                'get_announcement_type_display': announcement.get_announcement_type_display(),
                'is_urgent': announcement.is_urgent,
                'start_date': announcement.start_date.isoformat(),
                'type_icon': 'ri-notification-3-line',  # Default icon
            })
        
        return announcements_data
    
    def get_recent_questions(self):
        """Son 5 AskGT makalesi"""
        questions = Question.objects.filter(
            is_active=True
        ).select_related('category').order_by('-created_at')[:5]
        
        # JSON serializable hale getir
        questions_data = []
        for question in questions:
            questions_data.append({
                'id': question.id,
                'title': question.title,
                'category': {
                    'name': question.category.name,
                    'icon': getattr(question.category, 'icon', 'ri-question-answer-line'),
                },
                'is_featured': getattr(question, 'is_featured', False),
                'view_count': getattr(question, 'view_count', 0),
            })
        
        return questions_data
    
    def get_system_activities(self):
        """Sistem aktiviteleri"""
        activities = []
        
        # Son otomasyon görevleri
        try:
            recent_tasks = AutomationTask.objects.filter(
                is_active=True
            ).order_by('-created_at')[:3]
            
            for task in recent_tasks:
                activities.append({
                    'type': 'automation',
                    'title': f'Otomasyon: {task.name}',
                    'description': f'Durum: {task.get_status_display()}',
                    'timestamp': task.created_at.isoformat(),
                    'icon': 'ri-settings-3-line',
                    'color': getattr(task, 'status_color', 'info'),
                    'url': f'/automation/task/{task.id}/'
                })
        except:
            pass
        
        # Son sorular
        recent_questions = Question.objects.filter(
            is_active=True
        ).order_by('-created_at')[:2]
        
        for question in recent_questions:
            activities.append({
                'type': 'askgt',
                'title': f'Yeni Soru: {question.title[:50]}...',
                'description': f'Kategori: {question.category.name}',
                'timestamp': question.created_at.isoformat(),
                'icon': 'ri-question-answer-line',
                'color': 'info',
                'url': f'/askgt/question/{question.id}/'
            })
        
        # Zaman sırasına göre sırala
        activities.sort(key=lambda x: x['timestamp'], reverse=True)
        
        return activities[:5]
    
    def get_quick_links(self):
        """Hızlı erişim linkleri"""
        return ImportantLink.objects.filter(
            is_active=True
        ).order_by('category', 'order')[:8]

# AJAX Views for Asynchronous Loading
@login_required
def dashboard_summary_api(request):
    """Dashboard özet kartları API"""
    cache_key = f"dashboard_summary_{request.user.id}"
    data = cache.get(cache_key)
    
    if not data:
        view = DashboardView()
        data = view.get_summary_cards()
        cache.set(cache_key, data, 300)
    
    return JsonResponse(data)

@login_required
def dashboard_performance_api(request):
    """Dashboard performans grafiği API"""
    cache_key = f"dashboard_performance_{request.user.id}"
    data = cache.get(cache_key)
    
    if not data:
        view = DashboardView()
        data = view.get_performance_data()
        cache.set(cache_key, data, 300)
    
    return JsonResponse(data)

@login_required
def dashboard_inventory_api(request):
    """Dashboard envanter sağlık API"""
    cache_key = f"dashboard_inventory_{request.user.id}"
    data = cache.get(cache_key)
    
    if not data:
        view = DashboardView()
        data = view.get_inventory_health()
        cache.set(cache_key, data, 300)
    
    return JsonResponse(data)

@login_required
def dashboard_activities_api(request):
    """Dashboard sistem aktiviteleri API"""
    cache_key = f"dashboard_activities_{request.user.id}"
    data = cache.get(cache_key)
    
    if not data:
        view = DashboardView()
        data = view.get_system_activities()
        cache.set(cache_key, data, 300)
    
    return JsonResponse(data, safe=False)

@login_required
def dashboard_jboss8_api(request):
    """JBoss 8 migrasyon istatistikleri API"""
    cache_key = f"dashboard_jboss8_{request.user.id}"
    data = cache.get(cache_key)
    
    if not data:
        view = DashboardView()
        data = view.get_jboss8_migration_stats()
        cache.set(cache_key, data, 300)
    
    return JsonResponse(data)

# Legacy function-based view (kept for compatibility)
@login_required
def dashboard(request):
    """Legacy dashboard view - redirects to class-based view"""
    view = DashboardView.as_view()
    return view(request)

@login_required
def search_results(request):
    """Arama sonuçları"""
    query = request.GET.get('q', '')
    results = []
    
    if query:
        # Haystack ile arama yap
        sqs = SearchQuerySet().auto_query(query)
        
        # Sonuçları kategorilere ayır
        servers = []
        applications = []
        questions = []
        announcements = []
        
        for result in sqs:
            if result.model_name == 'server':
                servers.append(result)
            elif result.model_name == 'application':
                applications.append(result)
            elif result.model_name == 'question':
                questions.append(result)
            elif result.model_name == 'announcement':
                announcements.append(result)
        
        results = {
            'servers': servers[:10],
            'applications': applications[:10],
            'questions': questions[:10],
            'announcements': announcements[:10],
        }
    
    context = {
        'query': query,
        'results': results,
        'total_results': sum(len(v) for v in results.values()) if results else 0,
    }
    return render(request, 'core/search_results.html', context)
