from django import template
from django.utils import timezone
from datetime import timedelta
import json

register = template.Library()

@register.filter
def to_json(value):
    """Python objesini JSON'a çevir"""
    return json.dumps(value, default=str, ensure_ascii=False)

@register.filter
def time_since_short(value):
    """Kısa zaman farkı gösterimi"""
    if not value:
        return ""
    
    now = timezone.now()
    diff = now - value
    
    if diff.days > 0:
        return f"{diff.days}g"
    elif diff.seconds > 3600:
        return f"{diff.seconds // 3600}s"
    elif diff.seconds > 60:
        return f"{diff.seconds // 60}d"
    else:
        return "şimdi"

@register.simple_tag
def dashboard_card_color(value, threshold_warning=80, threshold_critical=95):
    """Dashboard kartları için renk belirleme"""
    if value >= threshold_critical:
        return "danger"
    elif value >= threshold_warning:
        return "warning"
    else:
        return "success"

@register.inclusion_tag('core/widgets/stat_card.html')
def stat_card(title, value, icon, color="primary", url=None, subtitle=None):
    """İstatistik kartı widget'ı"""
    return {
        'title': title,
        'value': value,
        'icon': icon,
        'color': color,
        'url': url,
        'subtitle': subtitle,
    }

@register.inclusion_tag('core/widgets/activity_item.html')
def activity_item(activity):
    """Aktivite öğesi widget'ı"""
    return {'activity': activity}
