from django.core.management.base import BaseCommand
from django.utils import timezone
from duty_schedule.services import DutySyncService
from duty_schedule.models import DutySyncSource

class Command(BaseCommand):
    help = 'Nöbet listesini harici kaynaklardan senkronize eder'
    
    def add_arguments(self, parser):
        parser.add_argument(
            '--source',
            type=str,
            help='Belirli bir kaynağı senkronize et (kaynak adı)',
        )
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Sadece test et, veritabanını güncelleme',
        )
        parser.add_argument(
            '--verbose',
            action='store_true',
            help='Detaylı çıktı göster',
        )
    
    def handle(self, *args, **options):
        service = DutySyncService()
        
        try:
            if options['source']:
                # Belirli kaynak
                try:
                    source = DutySyncSource.objects.get(
                        name=options['source'], 
                        is_active=True
                    )
                    
                    if options['verbose']:
                        self.stdout.write(f"Kaynak senkronize ediliyor: {source.name}")
                    
                    if not options['dry_run']:
                        result = service.sync_source(source)
                        self.stdout.write(
                            self.style.SUCCESS(
                                f"✓ {source.name}: {result['processed']} kayıt işlendi, "
                                f"{result['created']} oluşturuldu, {result['updated']} güncellendi"
                            )
                        )
                    else:
                        self.stdout.write(f"DRY RUN: {source.name} senkronize edilecekti")
                        
                except DutySyncSource.DoesNotExist:
                    self.stdout.write(
                        self.style.ERROR(f"Kaynak bulunamadı: {options['source']}")
                    )
                    return
            else:
                # Tüm kaynaklar
                sources = DutySyncSource.objects.filter(is_active=True)
                
                if not sources.exists():
                    self.stdout.write(
                        self.style.WARNING("Aktif senkronizasyon kaynağı bulunamadı")
                    )
                    return
                
                if options['verbose']:
                    self.stdout.write(f"{sources.count()} kaynak senkronize ediliyor...")
                
                if not options['dry_run']:
                    results = service.sync_all_sources()
                    
                    total_processed = sum(r['processed'] for r in results)
                    total_created = sum(r['created'] for r in results)
                    total_updated = sum(r['updated'] for r in results)
                    
                    self.stdout.write(
                        self.style.SUCCESS(
                            f"✓ Senkronizasyon tamamlandı: {total_processed} kayıt işlendi, "
                            f"{total_created} oluşturuldu, {total_updated} güncellendi"
                        )
                    )
                else:
                    self.stdout.write(f"DRY RUN: {sources.count()} kaynak senkronize edilecekti")
        
        except Exception as e:
            self.stdout.write(
                self.style.ERROR(f"Senkronizasyon hatası: {str(e)}")
            )
