from celery import shared_task
from django.utils import timezone
from .services import DutySyncService
from .models import DutySyncSource
import logging

logger = logging.getLogger(__name__)

@shared_task(bind=True)
def sync_duty_schedules(self):
    """Nöbet listelerini senkronize et"""
    try:
        service = DutySyncService()
        results = service.sync_all_sources()
        
        total_processed = sum(r['processed'] for r in results)
        total_created = sum(r['created'] for r in results)
        total_updated = sum(r['updated'] for r in results)
        
        logger.info(
            f"Nöbet senkronizasyonu tamamlandı: {total_processed} kayıt işlendi, "
            f"{total_created} oluşturuldu, {total_updated} güncellendi"
        )
        
        return {
            'status': 'success',
            'processed': total_processed,
            'created': total_created,
            'updated': total_updated
        }
        
    except Exception as e:
        logger.error(f"Nöbet senkronizasyon hatası: {str(e)}")
        raise self.retry(exc=e, countdown=300, max_retries=3)

@shared_task
def sync_single_source(source_id):
    """Tek kaynak senkronizasyonu"""
    try:
        source = DutySyncSource.objects.get(id=source_id, is_active=True)
        service = DutySyncService()
        result = service.sync_source(source)
        
        logger.info(f"Kaynak senkronizasyonu tamamlandı: {source.name}")
        return result
        
    except Exception as e:
        logger.error(f"Kaynak senkronizasyon hatası: {str(e)}")
        raise e

@shared_task
def cleanup_old_duties():
    """Eski nöbet kayıtlarını temizle"""
    from datetime import timedelta
    from .models import DutySchedule
    
    # 2 yıldan eski kayıtları pasif yap
    cutoff_date = timezone.now().date() - timedelta(days=730)
    
    updated = DutySchedule.objects.filter(
        date__lt=cutoff_date,
        is_active=True
    ).update(is_active=False)
    
    logger.info(f"Eski nöbet kayıtları temizlendi: {updated} kayıt")
    return updated
