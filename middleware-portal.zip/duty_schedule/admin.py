from django.contrib import admin
from .models import DutySchedule, DutySyncSource, DutySyncLog

@admin.register(DutySchedule)
class DutyScheduleAdmin(admin.ModelAdmin):
    list_display = ['date', 'primary_person', 'secondary_person', 'phone', 'department', 'is_weekend', 'is_holiday', 'is_active']
    list_filter = ['is_weekend', 'is_holiday', 'is_active', 'department', 'date']
    search_fields = ['primary_person', 'secondary_person', 'phone', 'email', 'department']
    date_hierarchy = 'date'
    list_editable = ['is_active']
    readonly_fields = ['created_at', 'updated_at']
    
    fieldsets = (
        ('Temel Bilgiler', {
            'fields': ('date', 'primary_person', 'secondary_person')
        }),
        ('İletişim', {
            'fields': ('phone', 'email', 'department')
        }),
        ('Durum', {
            'fields': ('is_weekend', 'is_holiday', 'is_active')
        }),
        ('Notlar', {
            'fields': ('notes',)
        }),
        ('Sistem', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

@admin.register(DutySyncSource)
class DutySyncSourceAdmin(admin.ModelAdmin):
    list_display = ['name', 'source_type', 'url', 'last_sync', 'sync_interval', 'is_active']
    list_filter = ['source_type', 'auth_required', 'is_active']
    search_fields = ['name', 'url']
    readonly_fields = ['last_sync', 'created_at', 'updated_at']
    
    fieldsets = (
        ('Temel Bilgiler', {
            'fields': ('name', 'source_type', 'url')
        }),
        ('Kimlik Doğrulama', {
            'fields': ('auth_required', 'username', 'password', 'api_key')
        }),
        ('Yapılandırma', {
            'fields': ('headers', 'field_mapping', 'sync_interval')
        }),
        ('Durum', {
            'fields': ('is_active', 'last_sync')
        }),
        ('Sistem', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

@admin.register(DutySyncLog)
class DutySyncLogAdmin(admin.ModelAdmin):
    list_display = ['source', 'status', 'records_processed', 'records_created', 'records_updated', 'created_at']
    list_filter = ['status', 'source', 'created_at']
    search_fields = ['source__name', 'error_message']
    readonly_fields = ['created_at']
    
    def has_add_permission(self, request):
        return False
    
    def has_change_permission(self, request, obj=None):
        return False
