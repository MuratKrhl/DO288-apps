from django.urls import path
from . import views

app_name = 'duty_schedule'

urlpatterns = [
    # Main views
    path('', views.DutyScheduleListView.as_view(), name='duty_list'),
    path('calendar/', views.duty_calendar_view, name='duty_calendar'),
    path('detail/<int:pk>/', views.duty_detail_view, name='duty_detail'),
    path('logs/', views.sync_logs_view, name='sync_logs'),
    
    # API endpoints
    path('api/list/', views.duty_api_list, name='duty_api_list'),
    path('api/today/', views.today_duty_api, name='today_duty_api'),
]
