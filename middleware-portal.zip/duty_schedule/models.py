from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
from core.models import BaseModel
from datetime import date

class DutySchedule(BaseModel):
    """Nöbet çizelgesi modeli"""
    date = models.DateField(unique=True, verbose_name="Tarih")
    primary_person = models.CharField(max_length=100, verbose_name="Birincil Nöbetçi")
    secondary_person = models.CharField(max_length=100, blank=True, verbose_name="İkincil Nöbetçi")
    phone = models.CharField(max_length=20, blank=True, verbose_name="Telefon")
    email = models.EmailField(blank=True, verbose_name="E-posta")
    department = models.CharField(max_length=100, blank=True, verbose_name="Departman")
    notes = models.TextField(blank=True, verbose_name="Notlar")
    is_holiday = models.BooleanField(default=False, verbose_name="Tatil Günü")
    is_weekend = models.BooleanField(default=False, verbose_name="Hafta Sonu")
    
    class Meta:
        verbose_name = "Nöbet Çizelgesi"
        verbose_name_plural = "Nöbet Çizelgeleri"
        ordering = ['-date']
        indexes = [
            models.Index(fields=['date']),
            models.Index(fields=['primary_person']),
            models.Index(fields=['is_holiday', 'is_weekend']),
        ]
    
    def __str__(self):
        return f"{self.date.strftime('%d.%m.%Y')} - {self.primary_person}"
    
    @property
    def is_today(self):
        """Bugünkü nöbet mi?"""
        return self.date == timezone.now().date()
    
    @property
    def is_past(self):
        """Geçmiş tarih mi?"""
        return self.date < timezone.now().date()
    
    @property
    def day_name(self):
        """Gün adı"""
        days = ['Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi', 'Pazar']
        return days[self.date.weekday()]
    
    @property
    def status_color(self):
        """Durum rengi"""
        if self.is_today:
            return 'primary'
        elif self.is_past:
            return 'secondary'
        elif self.is_holiday:
            return 'danger'
        elif self.is_weekend:
            return 'warning'
        else:
            return 'success'

class DutySyncSource(BaseModel):
    """Nöbet listesi senkronizasyon kaynakları"""
    SOURCE_TYPES = [
        ('csv', 'CSV Dosyası'),
        ('excel', 'Excel Dosyası'),
        ('json', 'JSON API'),
        ('xml', 'XML Dosyası'),
    ]
    
    name = models.CharField(max_length=100, verbose_name="Kaynak Adı")
    source_type = models.CharField(max_length=20, choices=SOURCE_TYPES, verbose_name="Kaynak Tipi")
    url = models.URLField(verbose_name="Kaynak URL")
    auth_required = models.BooleanField(default=False, verbose_name="Kimlik Doğrulama Gerekli")
    username = models.CharField(max_length=100, blank=True, verbose_name="Kullanıcı Adı")
    password = models.CharField(max_length=100, blank=True, verbose_name="Şifre")
    api_key = models.CharField(max_length=200, blank=True, verbose_name="API Anahtarı")
    headers = models.JSONField(default=dict, blank=True, verbose_name="HTTP Headers")
    field_mapping = models.JSONField(default=dict, verbose_name="Alan Eşleştirme")
    last_sync = models.DateTimeField(null=True, blank=True, verbose_name="Son Senkronizasyon")
    sync_interval = models.PositiveIntegerField(default=1440, verbose_name="Senkronizasyon Aralığı (dakika)")
    
    class Meta:
        verbose_name = "Senkronizasyon Kaynağı"
        verbose_name_plural = "Senkronizasyon Kaynakları"
    
    def __str__(self):
        return f"{self.name} ({self.get_source_type_display()})"

class DutySyncLog(BaseModel):
    """Senkronizasyon log kayıtları"""
    STATUS_CHOICES = [
        ('success', 'Başarılı'),
        ('error', 'Hatalı'),
        ('warning', 'Uyarı'),
    ]
    
    source = models.ForeignKey(DutySyncSource, on_delete=models.CASCADE, verbose_name="Kaynak")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, verbose_name="Durum")
    records_processed = models.PositiveIntegerField(default=0, verbose_name="İşlenen Kayıt")
    records_created = models.PositiveIntegerField(default=0, verbose_name="Oluşturulan Kayıt")
    records_updated = models.PositiveIntegerField(default=0, verbose_name="Güncellenen Kayıt")
    error_message = models.TextField(blank=True, verbose_name="Hata Mesajı")
    execution_time = models.DurationField(null=True, blank=True, verbose_name="Çalışma Süresi")
    
    class Meta:
        verbose_name = "Senkronizasyon Log"
        verbose_name_plural = "Senkronizasyon Logları"
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.source.name} - {self.get_status_display()} ({self.created_at})"
