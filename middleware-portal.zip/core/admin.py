from django.contrib import admin
from .models import SystemSettings, ImportantLink, OnDutySchedule

@admin.register(SystemSettings)
class SystemSettingsAdmin(admin.ModelAdmin):
    list_display = ['key', 'value', 'is_active', 'updated_at']
    list_filter = ['is_active', 'created_at']
    search_fields = ['key', 'value', 'description']

@admin.register(ImportantLink)
class ImportantLinkAdmin(admin.ModelAdmin):
    list_display = ['title', 'category', 'url', 'order', 'is_active']
    list_filter = ['category', 'is_active']
    search_fields = ['title', 'description']
    list_editable = ['order', 'is_active']

@admin.register(OnDutySchedule)
class OnDutyScheduleAdmin(admin.ModelAdmin):
    list_display = ['date', 'primary_person', 'secondary_person', 'is_active']
    list_filter = ['is_active', 'date']
    search_fields = ['primary_person', 'secondary_person']
    date_hierarchy = 'date'
